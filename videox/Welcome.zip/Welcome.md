## Welcome

Save anything from the internet on your device for offline use!

Twitter, facebook, youtube, clouds - you name it.

### How to use

1. switch to browser tab

2. input a link to open a web-page

3. tap any hrefs you want to download, a download task will be created if the href you taped can be download.
